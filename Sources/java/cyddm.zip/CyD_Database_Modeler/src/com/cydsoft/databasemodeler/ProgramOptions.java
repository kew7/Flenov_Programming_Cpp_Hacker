/*
 * ProgramOptions.java
 */

package com.cydsoft.databasemodeler;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 *
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 *
 */
public class ProgramOptions {
    private Boolean bMarkIndexedField;
    private Boolean bMarkPrimaryKey;
    private Boolean bShowColumnTypes;
    private Boolean bShowTableScheme;
    private String filename;
    
    /** Creates a new instance of ProgramOptions */
    public ProgramOptions(){
        bMarkIndexedField = false;
        bMarkPrimaryKey = true;
        bShowColumnTypes = false;
        bShowTableScheme = true;
    }
    
    public ProgramOptions(String filename) {
        this.filename = filename;
        loadFromFile();
    }   
   
    /** Save options to file */
    public void saveToFile(){
        Properties p = new Properties();
        p.setProperty("representation.bMarkIndexedField", String.valueOf(bMarkIndexedField));
        p.setProperty("representation.bMarkPrimaryKey", String.valueOf(bMarkPrimaryKey));
        p.setProperty("representation.bShowColumnTypes", String.valueOf(bShowColumnTypes));
        p.setProperty("representation.bShowTableScheme", String.valueOf(bShowTableScheme));

        // save properties to file
        try {
            FileOutputStream fo = new FileOutputStream(filename);
            p.store(fo, "CyD Database Modeler Program Options");
            fo.close();
        } catch (Exception ee){
        }
    }
    
    /** Save options from file */
    private void loadFromFile(){
        Properties p = new Properties();
        
        // load properties from file
        try {
            FileInputStream fi = new FileInputStream(filename);
            p.load(fi);
            fi.close();
        } catch (Exception ee) {
        }
        
        setMarkIndexedField(Boolean.parseBoolean(p.getProperty("representation.bMarkIndexedField", "false")));
        setMarkPrimaryKey(Boolean.parseBoolean(p.getProperty("representation.bMarkPrimaryKey", "true")));
        setShowColumnTypes(Boolean.parseBoolean(p.getProperty("representation.bShowColumnTypes", "false")));
        setShowTableScheme(Boolean.parseBoolean(p.getProperty("representation.bShowTableScheme", "false")));
    }
    

    // Mark Indexed Field
    public Boolean getMarkIndexedField(){
        return bMarkIndexedField;
    }
    
    public void setMarkIndexedField(Boolean bMarkPrimaryKey){
        this.bMarkIndexedField = bMarkPrimaryKey;
    }

    // Mark Primary Key
    public Boolean getMarkPrimaryKey(){
        return bMarkPrimaryKey;
    }

    public void setMarkPrimaryKey(Boolean bMarkPrimaryKey){
        this.bMarkPrimaryKey = bMarkPrimaryKey;
    }

    // Show Column Types
    public Boolean getShowColumnTypes(){
        return bShowColumnTypes;
    }

    public void setShowColumnTypes(Boolean bShowColumnTypes){
        this.bShowColumnTypes = bShowColumnTypes;
    }

    // Show Table Scheme
    public Boolean getShowTableScheme(){
        return bShowTableScheme;
    }

    public void setShowTableScheme(Boolean bShowTableScheme){
        this.bShowTableScheme = bShowTableScheme;
    }
}
