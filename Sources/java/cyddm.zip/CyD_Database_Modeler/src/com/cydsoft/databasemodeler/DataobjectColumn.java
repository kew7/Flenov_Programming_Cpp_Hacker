package com.cydsoft.databasemodeler;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DataobjectColumn {
  private String type = "";
  private String name;
  private String description;
  private int scale;
  private int length;
  private String defaultValue;
  private boolean isNull;
  private boolean isPrimaryKey;
  private String primaryKeyName="";
  private boolean isIndexed;
  private String indexName="";

  public DataobjectColumn() {

  }

  // ============= Column Name ============= //
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  // ============= Column Type ============= //
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  // ============= Column Description ============= //
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  // ============= Column Scale ============= //
  public int getScale() {
    return scale;
  }
  public String getScaleString() {
    return String.valueOf(scale);
  }
  public void setScale(int scale) {
    this.scale = scale;
  }

  // ============= Column Length ============= //
  public int getLength() {
    return length;
  }
  public String getLengthString() {
    return String.valueOf(length);
  }
  public void setLength(int length) {
    this.length = length;
  }

  // ============= Column Default Value ============= //
  public String getDefaultValue() {
    return defaultValue;
  }
  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  // ============= Column Is Null ============= //
  public boolean isNull() {
    return isNull;
  }
  public String isNullString() {
    return String.valueOf(isNull);
  }
  public void setIsNull(boolean isNull) {
    this.isNull = isNull;
  }

  // ============= Column Is Primary Key ============= //
  public boolean isPrimaryKey() {
    return isPrimaryKey;
  }
  public String isPrimaryKeyString() {
    return String.valueOf(isPrimaryKey);
  }
  public void setIsPrimaryKey(boolean isPrimaryKey) {
    this.isPrimaryKey = isPrimaryKey;
  }

  // ============= Column Primary Key Name ============= //
  public String getPrimaryKeyName() {
    return primaryKeyName;
  }
  public void setPrimaryKeyName(String primaryKeyName) {
    this.primaryKeyName = primaryKeyName;
  }

  // ============= Column Index Name ============= //
  public String getIndexName() {
    return indexName;
  }
  public void setIndexName(String indexName) {
    this.indexName = indexName;
  }

  // ============= Column Is Indexed ============= //
  public boolean isIndexed() {
    return isIndexed;
  }
  public String isIndexedString() {
    return String.valueOf(isIndexed);
  }
  public void setIsIndexed(boolean isIndexed) {
    this.isIndexed = isIndexed;
  }

  // ============= To String ============= //
  public String toString(){
    return name;
  }
}
