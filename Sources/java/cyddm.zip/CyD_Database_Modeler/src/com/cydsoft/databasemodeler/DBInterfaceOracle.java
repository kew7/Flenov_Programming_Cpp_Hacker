package com.cydsoft.databasemodeler;

import java.util.Vector;
import javax.swing.tree.*;
import java.sql.*;

import com.cydsoft.common_files.*;
import javax.swing.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DBInterfaceOracle extends DBInterface {
  // ============= Constructor ============= //
  public DBInterfaceOracle(){
    super();
    setDBDriverName("oracle.jdbc.driver.OracleDriver");

    // database features
    setHaveCatalog(false);
    setHaveScheme(true);
    setHavePrimaryKey(true);
    fillColumnTypes();
  }

  // ============= Fill Column Types ============= //
  private void fillColumnTypes(){
      columnTypes.add(new DataobjectColumnType("CHAR", true, false));
      columnTypes.add(new DataobjectColumnType("DATE", false, false));
      columnTypes.add(new DataobjectColumnType("FLOAT", true, false));
      columnTypes.add(new DataobjectColumnType("LONG", false, false));
      columnTypes.add(new DataobjectColumnType("LONG RAW", false, false));
      columnTypes.add(new DataobjectColumnType("NUMBER", true, true));
      columnTypes.add(new DataobjectColumnType("ROWID", false, false));
      columnTypes.add(new DataobjectColumnType("VARCHAR2", true, false));
  }

  // ============= Get Database Name ============= //
  public String getDbName(){
   return "Oracle";
  }

  // ============= Get Database Catalog ============= //
  public void getDatabaseCatalog(DefaultMutableTreeNode SchemeTreeTop){
    SchemeTreeTop.removeAllChildren();
    DefaultMutableTreeNode newCatalog = new DefaultMutableTreeNode(new MetadataTreeNode("Catalog", MetadataTreeNode.DATABASE_CATALOG, ""));
    SchemeTreeTop.add(newCatalog);
    newCatalog.add(new DefaultMutableTreeNode(new MetadataTreeNode("Expand...", MetadataTreeNode.DATABASE_EXPAND)));
  }

  // ============= Delete Table From Database ============= //
  public void deleteTableFromDatabase(MetadataTreeNode nodeInfo){
    try{
      String tableName = nodeInfo.getSchemeName()+"."+nodeInfo.getTableName();
      statement.executeUpdate("DROP TABLE "+tableName);
      System.out.println("Table "+tableName+" deleted");
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Empty Table ============= //
  public void emptyTable(MetadataTreeNode nodeInfo){
    try{
      String tableName = nodeInfo.getSchemeName()+"."+nodeInfo.getTableName();
      statement.executeUpdate("DELETE FROM "+tableName);
      System.out.println("Table "+tableName+" deleted");
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database Schemes ============= //
  public void getDatabaseSchemes(DefaultMutableTreeNode SchemeTreeTop){
    try{
      SchemeTreeTop.removeAllChildren();
      ResultSet SchemesResultSet = statement.executeQuery("SELECT DISTINCT Owner FROM SYS.ALL_TABLES ORDER BY Owner");
      while (SchemesResultSet.next()){
        DefaultMutableTreeNode newScheme = new DefaultMutableTreeNode(new MetadataTreeNode((String)SchemesResultSet.getObject(1),
            MetadataTreeNode.DATABASE_SCHEME, "", (String)SchemesResultSet.getObject(1)));
        SchemeTreeTop.add(newScheme);
        newScheme.add(new DefaultMutableTreeNode(new MetadataTreeNode("Expand...", MetadataTreeNode.DATABASE_EXPAND)));
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database Tables Node Infos From Scheme ============= //
  public Vector getDatabaseTablesNodeInfoFromScheme(MetadataTreeNode nodeInfo){
    Vector Schemes = new Vector();
    try{
      String query ="SELECT Table_Name FROM SYS.ALL_TABLES WHERE owner='"+nodeInfo.getObjectName()+"' ORDER BY Table_Name";

      ResultSet SchemesResultSet = statement.executeQuery(query);
      while (SchemesResultSet.next()){
        MetadataTreeNode newInfo = new MetadataTreeNode((String)SchemesResultSet.getObject(1),
            MetadataTreeNode.DATABASE_TABLE,
            "",
            nodeInfo.getSchemeName(),
            (String)SchemesResultSet.getObject(1));
        Schemes.add(newInfo);
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    return Schemes;
  }

  // ============= Get Database Tables From Scheme ============= //
  public void getDatabaseTablesFromScheme(DefaultMutableTreeNode SchemeTreeTop){
    try{
      SchemeTreeTop.removeAllChildren();

      MetadataTreeNode nodeInfo = (MetadataTreeNode)SchemeTreeTop.getUserObject();
      String query ="SELECT TABLE_NAME FROM SYS.ALL_TABLES WHERE OWNER='"+nodeInfo.getObjectName()+"' ORDER BY Table_Name";

      ResultSet SchemesResultSet = statement.executeQuery(query);
      while (SchemesResultSet.next()){
        DefaultMutableTreeNode newTable = new DefaultMutableTreeNode(
            new MetadataTreeNode((String)SchemesResultSet.getObject(1),
                                 MetadataTreeNode.DATABASE_TABLE,
                                 "",
                                 nodeInfo.getObjectName(),
                                 (String)SchemesResultSet.getObject(1))
            );
        SchemeTreeTop.add(newTable);
        newTable.add(new DefaultMutableTreeNode(new MetadataTreeNode("Expand...", MetadataTreeNode.DATABASE_EXPAND)));
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database Columns From Table ============= //
  void getDatabaseColumnsFromTable(MetadataTreeNode nodeInfo, DataobjectTable table){
    try{
      String query ="SELECT * FROM "+nodeInfo.getSchemeName()+"."+nodeInfo.getTableName()+" WHERE rownum=0";

      ResultSet SchemesResultSet = statement.executeQuery(query);
      ResultSetMetaData metaData = SchemesResultSet.getMetaData();
      int numberOfColumns =  metaData.getColumnCount();
      for(int columnIndex = 1; columnIndex <= numberOfColumns; columnIndex++) {
        DataobjectColumn newColumn = new DataobjectColumn();
        newColumn.setName(metaData.getColumnLabel(columnIndex));
        newColumn.setType(metaData.getColumnTypeName(columnIndex));
        newColumn.setScale(metaData.getScale(columnIndex));
        newColumn.setLength(metaData.getPrecision(columnIndex));
        if  (metaData.isNullable(columnIndex)==metaData.columnNullable)
          newColumn.setIsNull(true);
        else
          newColumn.setIsNull(false);
        table.addColumn(newColumn);
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database Indexes From Table ============= //
  void getDatabaseIndexesFromTable(DefaultMutableTreeNode treeTop){
    treeTop.removeAllChildren();
    try{
      ResultSet SchemesResultSet;
      MetadataTreeNode nodeInfo = (MetadataTreeNode)treeTop.getUserObject();

      SchemesResultSet = statement.executeQuery(
            "SELECT INDEX_NAME FROM SYS.ALL_INDEXES WHERE Table_Owner = '" +
            nodeInfo.getSchemeName().toUpperCase() + "' AND Table_Name = '" +
            nodeInfo.getTableName().toUpperCase() + "'");

      while (SchemesResultSet.next()){
        DefaultMutableTreeNode newTable = new DefaultMutableTreeNode(
            new MetadataTreeNode((String)SchemesResultSet.getObject(1),
                                 MetadataTreeNode.DATABASE_INDEX,
                                 "",
                                 nodeInfo.getSchemeName(),
                                 nodeInfo.getTableName())
            );
        treeTop.add(newTable);
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database Columns From Table ============= //
  void getDatabaseColumnsFromTable(DefaultMutableTreeNode SchemeTreeTop){
    try{
      SchemeTreeTop.removeAllChildren();

      MetadataTreeNode nodeInfo = (MetadataTreeNode)SchemeTreeTop.getUserObject();
      String query ="SELECT * FROM "+nodeInfo.getSchemeName()+"."+nodeInfo.getTableName()+" WHERE rownum=0";

      ResultSet SchemesResultSet = statement.executeQuery(query);
      ResultSetMetaData metaData = SchemesResultSet.getMetaData();
      int numberOfColumns =  metaData.getColumnCount();
      for(int column = 1; column <= numberOfColumns; column++) {
        DefaultMutableTreeNode newTable = new DefaultMutableTreeNode(
            new MetadataTreeNode(metaData.getColumnLabel(column),
                                 MetadataTreeNode.DATABASE_COLUMN,
                                 "",
                                 nodeInfo.getSchemeName(),
                                 nodeInfo.getTableName())
            );
        SchemeTreeTop.add(newTable);
      }
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Database URL Template ============= //
  public String getDbURLTemplate(){
    return "jdbc:oracle:thin:@HOSTNAME:1521:ORCL";
  }

  // ============= Get Column Definition ============= //
  protected String getColumnDefinition(DataobjectColumn column){
    // check column type
    if (getColumnType(column.getType())==null){
      JOptionPane.showMessageDialog(null, "Wrong type for column "+column.getName(), "Error", JOptionPane.ERROR_MESSAGE);
      return "";
    }

    // build definition
    String columnDef = column.getName()+" "+column.getType();

    if (getColumnType(column.getType()).isHaveLength()){
      columnDef = columnDef+"("+column.getLengthString();
      if ((getColumnType(column.getType()).isIsHaveScale()==true) &
          (column.getScale()>0))
        columnDef = columnDef +","+column.getScaleString();
      columnDef = columnDef+") ";
    }
    if (column.getDefaultValue().compareTo("")!=0)
      columnDef = columnDef+" DEFAULT '"+column.getDefaultValue()+"' ";
    if (column.isNull()==false)
      columnDef = columnDef+" NOT NULL";
    return columnDef;
  }

  // ============= Get Create Table Query ============= //
  public String getCreateTableQuery(DataobjectTable table){
    String query = "CREATE TABLE "+table.getTableURL()+" (\n";
    for (int i=0; i<table.getColumnNumber(); i++){
      if (i>0) query = query + ",\n";
      query = query + getColumnDefinition(table.getColumn(i));
    }
    query = query+"\n)\n";
    return query;
  }

  // ============= Apply Table To Database ============= //
  public void applyTableToDatabase(DataobjectTable table){
    if (isTableExists(table)){
      // update table
      updateTableFromDatabase(table);
    }
    else{
      // create new table
      String query = getCreateTableQuery(table);

      // execute query
      try{
        statement.executeUpdate(query);
        System.out.println("The "+table.getTableURL()+" table created");
      }
      catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      }
      // Create index
      createIndexes(table);
    }
    JOptionPane.showMessageDialog(null, "The model table and the database table sincronized", "Error", JOptionPane.INFORMATION_MESSAGE);
  }

  // ============= Create table indexes ============= //
  private void createIndexes(DataobjectTable table){
    for (int i=0; i<table.getColumnNumber(); i++){
      DataobjectColumn column = table.getColumn(i);

      // if is indexed
      if (column.isIndexed() | column.isPrimaryKey()){
        try{
          // check for index names
          if (column.isIndexed() && column.getIndexName().compareTo("")==0)
            column.setIndexName(table.getTableName()+"_"+column.getName()+"_ix");
          if (column.isPrimaryKey() && column.getPrimaryKeyName().compareTo("")==0)
            column.setPrimaryKeyName(table.getTableName()+"_"+column.getName()+"_pix");

          // does index exist?
          ResultSet SchemesResultSet;
          String indexName;
          if (column.isIndexed())
            indexName=column.getIndexName();
          else
            indexName=column.getPrimaryKeyName();
          if (table.getScheme().compareTo("")==0)
            SchemesResultSet = statement.executeQuery("SELECT INDEX_NAME FROM SYS.ALL_INDEXES WHERE Table_Owner = upper(user) AND Table_Name = '"+table.getTableName().toUpperCase()+"' AND INDEX_NAME= upper('"+indexName+"')");
          else
            SchemesResultSet = statement.executeQuery("SELECT INDEX_NAME FROM SYS.ALL_INDEXES WHERE Table_Owner = upper('"+table.getScheme().toUpperCase()+"') AND Table_Name = '"+table.getTableName().toUpperCase()+"' AND INDEX_NAME= upper('"+indexName+"')");

          // if index does not exist then create it
          if (!SchemesResultSet.next()){
            if (column.isIndexed())
              statement.executeQuery("CREATE INDEX "+column.getIndexName()+" ON "+table.getTableName()+"("+column.getName()+")");
            else
              statement.executeQuery("ALTER TABLE "+table.getTableName()+" add constraint "+column.getPrimaryKeyName()+" primary key "+"("+column.getName()+")");
          }
        }
        catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
        }
      }
    }
  }

  // ============= Is Table Exists ============= //
  public boolean isTableExists(DataobjectTable table){
    try{
      ResultSet SchemesResultSet;
      if (table.getScheme().compareTo("")==0)
        SchemesResultSet = statement.executeQuery("SELECT DISTINCT OWNER FROM SYS.ALL_TABLES WHERE Owner = user AND Table_Name = '"+table.getTableName().toUpperCase()+"'");
      else
        SchemesResultSet = statement.executeQuery("SELECT DISTINCT OWNER FROM SYS.ALL_TABLES WHERE Owner = '"+table.getScheme().toUpperCase()+"' AND Table_Name = '"+table.getTableName().toUpperCase()+"'");

      if (SchemesResultSet.next())
        return true;
      else
        return false;
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return false;
    }
  }

  // ============= Update Table From Database ============= //
  public void updateTableFromDatabase(DataobjectTable table){
    try{
      ArrayList modelColumns = (ArrayList)table.getColumns().clone();

      // get columns from table
      ResultSet SchemesResultSet = statement.executeQuery("SELECT * FROM "+table.getTableURL()+" WHERE rownum=0");
      ResultSetMetaData metaData = SchemesResultSet.getMetaData();
      int metaDataColumnCount = metaData.getColumnCount();

      // check all columns from metadata
      for (int queryColumn = 1; queryColumn <= metaDataColumnCount; queryColumn++) {
        DataobjectColumn modelColumnDef = null;

        // update existing columns
        for (int modelColumn = 0; modelColumn < modelColumns.size(); modelColumn++) {
           modelColumnDef = (DataobjectColumn) modelColumns.get(modelColumn);
           // if column found update it
           if (modelColumnDef.getName().compareToIgnoreCase(metaData.getColumnLabel(queryColumn))==0){
             // if column type is not equals model column type then update type
             boolean currentNullState=false;
             if  (metaData.isNullable(queryColumn)==metaData.columnNullable)
               currentNullState=true;

             if ((modelColumnDef.getType().compareToIgnoreCase(metaData.getColumnTypeName(queryColumn))!=0) |
                 (modelColumnDef.getLength()!=metaData.getPrecision(queryColumn)) |
                 (modelColumnDef.getScale()!=metaData.getScale(queryColumn)) |
                 (modelColumnDef.isNull()!=currentNullState)){
               try{
                 statement.executeQuery("ALTER TABLE "+table.getTableURL()+" MODIFY "+getColumnDefinition(modelColumnDef));
                 System.out.println("Column "+modelColumnDef.getName()+" updated");
               }
               catch (SQLException exupdate) {
                 JOptionPane.showMessageDialog(null, exupdate.toString(), "Error", JOptionPane.ERROR_MESSAGE);
               }
             }

             // remove checked column from model list
             modelColumns.remove(modelColumn);
             break;
           }
        }

        // if column not found in model then drop it
        if (modelColumnDef == null){
          String columnLabel = metaData.getColumnLabel(queryColumn);
          statement.executeQuery("ALTER TABLE " + table.getTableURL()+" DROP COLUMN " +columnLabel);
          System.out.println("Column " + columnLabel + " deleted");

          SchemesResultSet = statement.executeQuery("SELECT * FROM "+table.getTableURL()+" WHERE rownum=0");
          metaData = SchemesResultSet.getMetaData();
          metaDataColumnCount = metaData.getColumnCount();
          queryColumn--;

          continue;
        }
      }

      // add new columns
      for (int modelColumn = 0; modelColumn < modelColumns.size(); modelColumn++) {
        DataobjectColumn modelColumnDef = (DataobjectColumn) modelColumns.get(modelColumn);
        try{
          statement.executeQuery("ALTER TABLE "+table.getTableURL()+" ADD ("+getColumnDefinition(modelColumnDef)+")");
          System.out.println("Column "+modelColumnDef.getName()+" added");
        }
        catch (SQLException exupdate) {
          JOptionPane.showMessageDialog(null, exupdate.toString(), "Error", JOptionPane.ERROR_MESSAGE);
        }
      // create indexes
     }
     createIndexes(table);
     System.out.println("Table sinchronized");
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
  // ============= Get Select Query ============= //
  public String getSelectQuery(String tableURL, int rowLimit){
    String query = "SELECT t.*, t.rowid FROM "+tableURL+" t ";
    if (rowLimit>0)
      query = query + " WHERE rownum<"+rowLimit;

    return query;
  }

  // ============= Delete Index From Scheme ============= //
  void deleteIndexFromDatabase(MetadataTreeNode nodeInfo){
    try{
      ResultSet SchemesResultSet;
      SchemesResultSet = statement.executeQuery("DROP INDEX "+nodeInfo.getSchemeName()+"."+nodeInfo.getObjectName());
      System.out.println("Index "+nodeInfo.getObjectName()+" deleted");
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Delete Field From Scheme ============= //
  void deleteFieldFromDatabase(MetadataTreeNode nodeInfo){
    try{
      ResultSet SchemesResultSet;
      SchemesResultSet = statement.executeQuery("ALTER TABLE "+nodeInfo.getSchemeName()+"."+nodeInfo.getTableName()+" DROP COLUMN "+nodeInfo.getObjectName());
      System.out.println("Field "+nodeInfo.getObjectName()+" deleted from table "+nodeInfo.getTableName());
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
}
