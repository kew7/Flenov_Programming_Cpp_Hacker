package com.cydsoft.databasemodeler;

import java.util.*;
import java.sql.*;
import javax.swing.tree.*;
import javax.swing.*;

import com.cydsoft.common_files.*;
import com.cydsoft.databasemodeler.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public abstract class DBInterface {
  private String dbURL;
  private String dbUserName = "";
  private String dbPassword = "";
  private boolean connected;
  private boolean haveCatalog;
  private boolean haveScheme;
  private boolean havePrimaryKey;

  private String dbDriverName;
  protected Connection connection;
  protected Statement statement;
  protected Vector columnTypes=new Vector();

  // ============= Constructor ============= //
  public DBInterface(){
    setConnected(false);
    dbURL = getDbURLTemplate();
  }

  //////////////////////////////////////////////////
  ////////////// ABSTRACT METHODS //////////////////
  //////////////////////////////////////////////////

  // ============= Get Database Name ============= //
  abstract String getDbName();

  // ============= Get Database Name ============= //
  abstract String getDbURLTemplate();

  // ============= Get Database Schemes ============= //
  abstract void getDatabaseSchemes(DefaultMutableTreeNode SchemeTreeTop);

  // ============= Get Database Catalogs ============= //
  abstract void getDatabaseCatalog(DefaultMutableTreeNode SchemeTreeTop);

  // ============= Get Database Tables From Scheme ============= //
  abstract void getDatabaseTablesFromScheme(DefaultMutableTreeNode SchemeTreeTop);

  // ============= Get Database Columns From Table ============= //
  abstract void getDatabaseColumnsFromTable(DefaultMutableTreeNode SchemeTreeTop);

  // ============= Get Database Indexes From Table ============= //
  abstract void getDatabaseIndexesFromTable(DefaultMutableTreeNode treeTop);

  // ============= Get Database Columns From Table ============= //
  abstract void getDatabaseColumnsFromTable(MetadataTreeNode nodeInfo, DataobjectTable table);

  // ============= Is Table Exists ============= //
  abstract boolean isTableExists(DataobjectTable table);

  // ============= Apply Table To Database ============= //
  abstract void applyTableToDatabase(DataobjectTable table);

  // ============= Update Table From Database ============= //
  abstract void updateTableFromDatabase(DataobjectTable table);

  // ============= Get Column Definition ============= //
  abstract String getColumnDefinition(DataobjectColumn column);

  // ============= Get Select Query ============= //
  abstract String getSelectQuery(String tableURL, int rowLimit);

  // ============= Get Create Table Query ============= //
  abstract String getCreateTableQuery(DataobjectTable table);

  // ============= Get Database Tables Node Infos From Scheme ============= //
  abstract Vector getDatabaseTablesNodeInfoFromScheme(MetadataTreeNode nodeInfo);

  // ============= Delete Index From Scheme ============= //
  abstract void deleteIndexFromDatabase(MetadataTreeNode nodeInfo);

  // ============= Delete Field From Scheme ============= //
  abstract void deleteFieldFromDatabase(MetadataTreeNode nodeInfo);
  
  // ============= Delete Table From Database ============= //
  abstract void deleteTableFromDatabase(MetadataTreeNode nodeInfo);
  
  // ============= Empty Table ============= //
  abstract void emptyTable(MetadataTreeNode nodeInfo);

  //////////////////////////////////////////////////
  ////////////// COMPLETE METHODS //////////////////
  //////////////////////////////////////////////////
  
  // ============= Delete Table From Database ============= //
  void deleteTableFromDatabase(DataobjectTable table){
    try{
      statement.executeUpdate("DROP TABLE "+table.getTableURL());
      System.out.println("Table "+table.getTableURL()+" deleted");
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Table Roots ============= //
  public void getDatabaseTableRoots(DefaultMutableTreeNode treeTop){
    treeTop.removeAllChildren();

    // add columns root
    MetadataTreeNode nodeInfo = (MetadataTreeNode)treeTop.getUserObject();

    DefaultMutableTreeNode columnsRoot = new DefaultMutableTreeNode(new MetadataTreeNode("Columns", MetadataTreeNode.DATABASE_COLUMNROOT, "", nodeInfo.getSchemeName(), nodeInfo.getTableName()));
    treeTop.add(columnsRoot);
    columnsRoot.add(new DefaultMutableTreeNode(new MetadataTreeNode("Expand...", MetadataTreeNode.DATABASE_EXPAND, "")));

    // add indexes root
    DefaultMutableTreeNode indexesRoot = new DefaultMutableTreeNode(new MetadataTreeNode("Indexes", MetadataTreeNode.DATABASE_INDEXESROOT, "", nodeInfo.getSchemeName(), nodeInfo.getTableName()));
    treeTop.add(indexesRoot);
    indexesRoot.add(new DefaultMutableTreeNode(new MetadataTreeNode("Expand...", MetadataTreeNode.DATABASE_EXPAND, "")));
  }

  // ============= Get Column Types ============= //
  public Vector getColumnTypes(){
    return columnTypes;
  }

  // ============= Get Column Type By Name ============= //
  public DataobjectColumnType getColumnType(String name){
    for (int i=0; i<columnTypes.size(); i++){
      DataobjectColumnType currentType = (DataobjectColumnType)columnTypes.get(i);
      if (currentType.getName().compareTo(name)==0)
        return currentType;
    }
    return null;
  }

  // ============= Get Database URL ============= //
  public String getDbURL() {
    return dbURL;
  }

  // ============= Set Database URL ============= //
  public void setDbURL(String dbURL) {
    if ("".compareTo(dbURL)==0)
      this.dbURL = getDbURLTemplate();
    else
      this.dbURL = dbURL;
  }

  // ============= Get Database Username ============= //
  public String getDbUserName() {
    return dbUserName;
  }

  // ============= Set Database Username ============= //
  public void setDbUserName(String dbUserName) {
    this.dbUserName = dbUserName;
  }

  // ============= Get Database Password ============= //
  public String getDbPassword() {
    return dbPassword;
  }

  // ============= Set Database Password ============= //
  public void setDbPassword(String dbPassword) {
    this.dbPassword = dbPassword;
  }

  // ============= Set Connection Status ============= //
  public void setConnected(boolean isConnected){
    this.connected = isConnected;
  }

  // ============= Get Connection Status ============= //
  public boolean isConnected(){
    return connected;
  }

  // ============= Set Database Driver Name ============= //
  protected void setDBDriverName(String dbDriverName){
    this.dbDriverName=dbDriverName;
  }

  // ============= Is Have Catalog ============= //
  public boolean isHaveCatalog() {
    return haveCatalog;
  }

  // ============= Set Have Catalog ============= //
  protected void setHaveCatalog(boolean haveCatalog) {
    this.haveCatalog = haveCatalog;
  }

  // ============= Is Have Primary Key ============= //
  public boolean isHavePrimaryKey() {
    return havePrimaryKey;
  }

  // ============= Set Have Catalog ============= //
  protected void setHavePrimaryKey(boolean havePrimaryKey) {
    this.havePrimaryKey = havePrimaryKey;
  }

  // ============= Is Have Scheme ============= //
  public boolean isHaveScheme() {
    return haveScheme;
  }

  // ============= Set Have Scheme ============= //
  protected void setHaveScheme(boolean haveScheme) {
    this.haveScheme = haveScheme;
  }

  // ============= Connect To Database ============= //
  public boolean connectToDatabase() {
    try {
      // register driver
      Class.forName(dbDriverName);
      System.out.println("Opening database connection");

      // connect to database
      connection = DriverManager.getConnection(dbURL, dbUserName, dbPassword);
      statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
    }
    catch (ClassNotFoundException ex) {
      JOptionPane.showMessageDialog(null, "Cannot find the database driver classes. "+ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, "Cannot connect to this database. "+ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    catch (Exception ex) {
      JOptionPane.showMessageDialog(null, "Cannot connect to this database. "+ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return false;
    }

    // connection ok
    System.out.println("Database connection opened");
    setConnected(true);
    return true;
  }

  // ============= Disconnect To Database ============= //
  public boolean disconnectFromDatabase(){
    try{
      connection.close();
    }
    catch (SQLException ex) {
      System.out.println("Can't close database");
      return false;
    }
    System.out.println("Database connection closed");
    setConnected(false);
    return true;
  }

  // ============= Get Database Info ============= //
  public String GetDatabaseInfo(){
    try{
      DatabaseMetaData md = connection.getMetaData();
      return "Database: ".concat(md.getDatabaseProductVersion());
    }
    catch (SQLException ex) {
      System.out.print(ex);
      return "Error";
    }
  }

  // ============= Get Database Info ============= //
  public ResultSet executeQuery(String query){
    try{
      return statement.executeQuery(query);
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return null;
    }
  }

  // ============= Execute Update ============= //
  public int executeUpdate(String query){
    try{
      int res = statement.executeUpdate(query);
      connection.commit();
      return res;
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return 0;
    }
  }

  // ============= Update One Row ============= //
  public int executeUpdateOneRow(String query){
    try{
      connection.setAutoCommit(false);
      Savepoint updatePoint = connection.setSavepoint("Update");
      int res = statement.executeUpdate(query);
      if (res==1)
        connection.commit();
      else
        connection.rollback(updatePoint);
      return res;
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
      return 0;
    }
  }

  // ============= Is Direct Update ============= //
  public boolean isDirectUpdate() {
    return true;
  }

  // ============= commit ============= //
  public void commit(){
    try{
      if (connection.getAutoCommit()==false)
        connection.commit();
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= rollback ============= //
  public void rollback(){
    try{
      connection.rollback();
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
}
