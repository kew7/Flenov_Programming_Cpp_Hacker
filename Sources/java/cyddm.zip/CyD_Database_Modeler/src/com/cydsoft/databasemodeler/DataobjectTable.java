package com.cydsoft.databasemodeler;

import java.awt.Image;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import com.cydsoft.*;

/**
 * <p>Title: dataObject main class </p>
 * <p>Description: CyD Database Modeler Main Frame</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DataobjectTable {
  // Variables
  private Image buffer=null;
  private Point startDragPoint;
  private ArrayList columns;
  private boolean selected;
  private ImageIcon imageKey;
  private ImageIcon imageIndex;

  // Properties
  private String catalog = "";
  private String Scheme = "";
  private String tableName;
  private String tableDescription;
  private Dimension size = new Dimension(175, 40);
  private Point location = new Point(10, 10);

  // ============= Constructor ============= //
  public DataobjectTable(){
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
 }

  // ============= jbInit ============= //
  private void jbInit() throws Exception {
    // Default values
    setTableName("Test Table");
    columns = new ArrayList();
    recalcDimension();
    imageKey = new ImageIcon(getClass().getResource("/com/cydsoft/databasemodeler/images/key.png"));
    imageIndex = new ImageIcon(getClass().getResource("/com/cydsoft/databasemodeler/images/sort.png"));
  }

  // ============= Get Table Name ============= //
  public String getTableName() {
    return tableName;
  }

  // ============= Set Table Name ============= //
  public void setTableName(String sTableName) {
    this.tableName = sTableName;
  }

  // ============= Recalc Dimension ============= //
  private void recalcDimension(){
    Dimension frmSize = this.getSize();
    this.setSize(new Dimension(frmSize.width, columns.size()*15+30));
    buffer=null;
  }

  // ============= Get Description ============= //
  public String getTableDescription() {
    return tableDescription;
  }

  // ============= Set Description ============= //
  public void setTableDescription(String sTableDescription) {
    this.tableDescription = sTableDescription;
  }

  // ============= Get Selected ============= //
  public boolean getSelected() {
    return selected;
  }

  // ============= Set Selected ============= //
  public void setSelected(boolean bSelected) {
    this.selected = bSelected;
  }

  // ============= Get Table Columns ============= //
  public java.util.ArrayList getColumns() {
    return columns;
  }

  // ============= Get Table Columns ============= //
  public DataobjectColumn getColumn(int index) {
    return (DataobjectColumn)columns.get(index);
  }

  // ============= Add Column ============= //
  public void addColumn(String name, String type, String desc) {
    DataobjectColumn newColumn = new DataobjectColumn();

    newColumn.setName(name);
    newColumn.setType(type);
    newColumn.setDescription(desc);

    columns.add(newColumn);
    recalcDimension();
  }

  // ============= Add Column ============= //
  public void addColumn(DataobjectColumn newColumn) {
    columns.add(newColumn);
    recalcDimension();
  }

  // ============= Add Column ============= //
  public void deleteColumn(int index) {
    columns.remove(index);
    recalcDimension();
  }

  // ============= Get Column Count ============= //
  public int getColumnNumber(){
    return columns.size();
  }

  // ============= Get Catalog ============= //
  public String getCatalog() {
    return catalog;
  }

  // ============= Set Catalog ============= //
  public void setCatalog(String catalog) {
    this.catalog = catalog;
  }

  // ============= Get Scheme ============= //
  public String getScheme() {
    return Scheme;
  }

  // ============= Set Scheme ============= //
  public void setScheme(String Scheme) {
    this.Scheme = Scheme;
  }

  // ============= Set Scheme ============= //
  public String getTableURL() {
    String tableURL = "";
    if (getCatalog().compareTo("")!=0)
      tableURL = tableURL+getCatalog()+".";
    if (getScheme().compareTo("")!=0)
      tableURL = tableURL+getScheme()+".";
    tableURL = tableURL.concat(getTableName());
    return tableURL;
  }

  // ============= Get Size ============= //
  public Dimension getSize() {
    return size;
  }

  // ============= Set Size ============= //
  public void setSize(Dimension size) {
    this.size = size;
  }

  // ============= Get Location ============= //
  public Point getLocation() {
    return location;
  }

  // ============= Set Location ============= //
  public void setLocation(Point location) {
    this.location = location;
  }

  // ============= Set Location ============= //
  public void setLocation(int x, int y){
    location.x = x;
    location.y = y;
  }

  // ============= Contains ============= //
  public boolean contains(int x, int y){
    if ((location.x < x) & (x < (location.x+size.width)))
      if ((location.y < y) & (y < (location.y+size.height)))
        return true;
    return false;
  }

  // ============= GetX ============= //
  public int getX(){
    return location.x;
  }

  // ============= GetY ============= //
  public int getY(){
    return location.y;
  }

  // ============= Set Bounds ============= //
  public void setBounds(int x, int y, int w, int h){
    location.x = x;
    location.y = y;
    size.width = w;
    size.height = h;
  }

  // ============= Paint ============= //
  public void paint(Graphics g){
      String sdraw;
      
      if (selected)          
          g.setColor(Color.blue);
      else
          g.setColor(Color.gray);
      
      g.fillRect(location.x, location.y, size.width, size.height);
      
      g.setColor(Color.white);
      g.fillRect(location.x+1, location.y+22, size.width-2, size.height-23);
      
      // Draw  caption
      sdraw = getTableName();
      if (ModelerMainFrame.getProgramOptions().getShowTableScheme())
          sdraw = getScheme() + "." + sdraw;
      g.drawString(getTableName(), location.x+4, location.y+15);
      
      // Draw Columns
      if (selected)
          g.setColor(Color.black);
      else
          g.setColor(Color.gray);
      
      for (int columnIndex=0; columnIndex<columns.size(); columnIndex++) {
          DataobjectColumn tf = (DataobjectColumn)columns.get(columnIndex);
          sdraw = tf.getName();
          
          // show column type if needed
          if (ModelerMainFrame.getProgramOptions().getShowColumnTypes())
              sdraw = sdraw + " ("+tf.getType()+")";
                    
          // show column type if needed
          if (tf.isIndexed())
              if (ModelerMainFrame.getProgramOptions().getMarkIndexedField())
                  g.drawImage(imageIndex.getImage(), location.x+2, location.y+15*(columnIndex)+30, null);

          if (tf.isPrimaryKey())
              if (ModelerMainFrame.getProgramOptions().getMarkPrimaryKey())
                  g.drawImage(imageKey.getImage(), location.x+10, location.y+15*(columnIndex)+30, null);
                          
          g.drawString(sdraw, location.x+18, location.y+15*(columnIndex)+40);          
      }
  }
}
