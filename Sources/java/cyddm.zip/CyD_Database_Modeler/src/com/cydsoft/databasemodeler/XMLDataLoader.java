package com.cydsoft.databasemodeler;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.*;
import java.util.ArrayList;
import java.awt.Point;
import java.util.Vector;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class XMLDataLoader extends DefaultHandler {
  // ============= Properties ============= //
  ArrayList arrayTables;
  ArrayList arrayLinks;
  DataobjectTable newTable = null;
  DataobjectColumn newColumn = null;
  DataobjectLink newLink = null;
  DBInterface database;
  Vector databaseList;

  // ============= Tags ============= //
  boolean isTableCatalog;
  boolean isTableScheme;
  boolean isTableName;
  boolean isTableDescription;
  boolean isTableXPosition;
  boolean isTableYPosition;

  boolean isColumnName;
  boolean isColumnDescription;
  boolean isColumnType;
  boolean isColumnLength;
  boolean isColumnScale;
  boolean isColumnDefault;
  boolean isColumnIsNull;
  boolean isColumnIsPrimaryKey;
  boolean isColumnPrimaryKeyName;
  boolean isColumnIsIndexed;
  boolean isColumnIndexName;

  boolean isDBName;
  boolean isConnectionURL;
  boolean isDBUserName;
  boolean isDBPassword;

  boolean isLink;
  boolean isMasterTableIndex;
  boolean isDetailTableIndex;
  boolean isMasterColumnIndex;
  boolean isDetailColumnIndex;

  // ============= Elements ============= //
  public void startElement(String nsURI, String localName, String rawName, Attributes attributes) throws SAXException {
    // database properties tags
    if (rawName.equalsIgnoreCase("DBName"))
      isDBName = true;
    if (rawName.equalsIgnoreCase("ConnectionURL"))
      isConnectionURL = true;
    if (rawName.equalsIgnoreCase("DBUserName"))
      isDBUserName = true;
    if (rawName.equalsIgnoreCase("DBPassword"))
      isDBPassword = true;

    // table tag
    if (rawName.equalsIgnoreCase("Table"))
    {
      newTable = new DataobjectTable();
      arrayTables.add(newTable);
    }

    // table properties tags
    if (rawName.equalsIgnoreCase("TableCatalog"))
      isTableCatalog = true;
    if (rawName.equalsIgnoreCase("TableScheme"))
      isTableScheme = true;
    if (rawName.equalsIgnoreCase("TableName"))
      isTableName = true;
    if (rawName.equalsIgnoreCase("TableDescription"))
      isTableDescription = true;
    if (rawName.equalsIgnoreCase("TableXPosition"))
      isTableXPosition = true;
    if (rawName.equalsIgnoreCase("TableYPosition"))
      isTableYPosition = true;

    // column tag
    if (rawName.equalsIgnoreCase("Column"))
    {
      newColumn = new DataobjectColumn();
      newTable.addColumn(newColumn);
    }

    // column properties tags
    if (rawName.equalsIgnoreCase("ColumnName"))
      isColumnName = true;
    if (rawName.equalsIgnoreCase("ColumnDescription"))
      isColumnDescription = true;
    if (rawName.equalsIgnoreCase("ColumnType"))
      isColumnType = true;
    if (rawName.equalsIgnoreCase("ColumnLength"))
      isColumnLength = true;
    if (rawName.equalsIgnoreCase("ColumnScale"))
      isColumnScale = true;
    if (rawName.equalsIgnoreCase("ColumnDefault"))
      isColumnDefault = true;
    if (rawName.equalsIgnoreCase("ColumnIsNull"))
      isColumnIsNull = true;
    if (rawName.equalsIgnoreCase("ColumnIsPrimaryKey"))
      isColumnIsPrimaryKey = true;
    if (rawName.equalsIgnoreCase("ColumnIsIndexed"))
      isColumnIsIndexed = true;
    if (rawName.equalsIgnoreCase("ColumnPrimaryKeyName"))
      isColumnPrimaryKeyName = true;
    if (rawName.equalsIgnoreCase("ColumnIndexName"))
      isColumnIndexName = true;

    // link tag
    if (rawName.equalsIgnoreCase("Link"))
    {
      newLink = new DataobjectLink();
      arrayLinks.add(newLink);
    }

    // link properties tags
    if (rawName.equalsIgnoreCase("MasterTableIndex"))
      isMasterTableIndex = true;
    if (rawName.equalsIgnoreCase("DetailTableIndex"))
      isDetailTableIndex = true;
    if (rawName.equalsIgnoreCase("MasterColumnIndex"))
      isMasterColumnIndex = true;
    if (rawName.equalsIgnoreCase("DetailColumnIndex"))
      isDetailColumnIndex = true;
  }

  public void characters(char[] ch, int start, int length) {
    String tagValue = new String(ch, start, length);
    if (ch[start]=='\n')
        tagValue = "";

    // database
    if (isDBName) {
      for (int i=0; i<databaseList.size(); i++)
      {
        DBInterface dbInterface = (DBInterface)databaseList.get(i);
        if (dbInterface.getDbName().compareTo(tagValue)==0){
          database = dbInterface;
          break;
        }
      }
      isDBName = false;
    } else if (isConnectionURL) {
       database.setDbURL(tagValue);
       isConnectionURL = false;
     } else if (isDBUserName) {
        database.setDbUserName(tagValue);
        isDBUserName = false;
      } else if (isDBPassword) {
         database.setDbPassword(tagValue);
         isDBPassword = false;
    }
    // table
    else if (isTableCatalog) {
       newTable.setCatalog(tagValue);
       isTableCatalog = false;
    } else if (isTableScheme) {
       newTable.setScheme(tagValue);
       isTableScheme = false;
    } else if (isTableName) {
       newTable.setTableName(tagValue);
       isTableName = false;
    } else if (isTableDescription) {
      newTable.setTableDescription(tagValue);
      isTableDescription = false;
    } else if (isTableXPosition) {
      newTable.setLocation(Integer.parseInt(tagValue), newTable.getLocation().y);
      isTableXPosition = false;
    } else if (isTableYPosition) {
      newTable.setLocation(newTable.getLocation().x, Integer.parseInt(tagValue));
      isTableYPosition = false;
    }
    // column
    else if (isColumnName) {
      newColumn.setName(tagValue);
      isColumnName = false;
    } else if (isColumnDescription) {
      newColumn.setDescription(tagValue);
      isColumnDescription = false;
    } else if (isColumnType) {
      newColumn.setType(tagValue);
      isColumnType = false;
    } else if (isColumnLength) {
      newColumn.setLength(Integer.parseInt(tagValue));
      isColumnLength = false;
    } else if (isColumnScale) {
      newColumn.setScale(Integer.parseInt(tagValue));
      isColumnScale = false;
    } else if (isColumnDefault) {
      newColumn.setDefaultValue(tagValue);
      isColumnDefault = false;
    } else if (isColumnIsNull) {
      newColumn.setIsNull(Boolean.valueOf(tagValue).booleanValue());
      isColumnIsNull = false;
    } else if (isColumnIsPrimaryKey) {
      newColumn.setIsPrimaryKey(Boolean.valueOf(tagValue).booleanValue());
      isColumnIsPrimaryKey = false;
    } else if (isColumnIsIndexed) {
      newColumn.setIsIndexed(Boolean.valueOf(tagValue).booleanValue());
      isColumnIsIndexed = false;
    } else if (isColumnPrimaryKeyName) {
      newColumn.setPrimaryKeyName(tagValue);
      isColumnPrimaryKeyName = false;
    } else if (isColumnIndexName) {
      newColumn.setIndexName(tagValue);
      isColumnIndexName = false;
    }
    // link
    else if (isMasterTableIndex) {
      DataobjectTable table = (DataobjectTable)arrayTables.get(Integer.parseInt(tagValue));
      if (table!=null)
        newLink.setMasterTable(table);
      isMasterTableIndex = false;
    }
    else if (isDetailTableIndex) {
      DataobjectTable table = (DataobjectTable)arrayTables.get(Integer.parseInt(tagValue));
      if (table!=null)
        newLink.setDetailTable(table);
      isDetailTableIndex = false;
    }
    else if (isMasterColumnIndex) {
      newLink.setMasterColumn(newLink.getMasterTable().getColumn(Integer.parseInt(tagValue)));
      isMasterColumnIndex = false;
    }
    else if (isDetailColumnIndex) {
      newLink.setDetailColumn(newLink.getDetailTable().getColumn(Integer.parseInt(tagValue)));
      isDetailColumnIndex = false;
    }
  }

  // ============= Constructor ============= //
  public XMLDataLoader(ArrayList arrayTables, DBInterface database, Vector databaseList, ArrayList arrayLinks) {
    super();
    this.arrayTables = arrayTables;
    this.arrayLinks = arrayLinks;
    this.database = database;
    this.databaseList = databaseList;
  }

  // ============= Get Databasse ============= //
  public DBInterface getDatabase(){
    return database;
  }
}
