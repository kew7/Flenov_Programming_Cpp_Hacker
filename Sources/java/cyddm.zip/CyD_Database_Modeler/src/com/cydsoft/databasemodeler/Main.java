/*
 * Main.java
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 *
 */

package com.cydsoft.databasemodeler;

import javax.swing.*;

/**
 *
 * @author Michael Flenov 
 * @web: http://www.flenov.com 
 * @web: http://www.cydsoft.com
 *
 */
public class Main {
    public static JFrame mainWindow;

    /** Creates a new instance of Main */
    public Main() {
        mainWindow = new ModelerMainFrame();
        mainWindow.validate();
        mainWindow.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Main();
    }
    
}
