package com.cydsoft.databasemodeler;

import java.util.*;

/**
 * <p>Title: CyD Database Modeller</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DataobjectLink {
  private DataobjectTable masterTable;
  private DataobjectTable detailTable;
  private DataobjectColumn masterColumn;
  private DataobjectColumn detailColumn;

  // ============= Constructor ============= //
  public DataobjectLink() {
  }

  public DataobjectLink(DataobjectTable masterTable, DataobjectTable detailTable) {
    this.masterTable = masterTable;
    this.detailTable = detailTable;
  }

  // ============= Get Master Table ============= //
  public DataobjectTable getMasterTable() {
    return masterTable;
  }

  // ============= Set Master Table ============= //
  public void setMasterTable(DataobjectTable masterTable) {
    this.masterTable = masterTable;
  }

  // ============= Get Detail Table ============= //
  public DataobjectTable getDetailTable() {
    return detailTable;
  }

  // ============= Set Detail Table ============= //
  public void setDetailTable(DataobjectTable detailTable) {
    this.detailTable = detailTable;
  }

  // ============= Get Master Column ============= //
  public DataobjectColumn getMasterColumn() {
    return masterColumn;
  }

  // ============= Get Detail Column ============= //
  public DataobjectColumn getDetailColumn() {
    return detailColumn;
  }

  // ============= Add Master Column ============= //
  public void setMasterColumn(DataobjectColumn newColumn) {
    masterColumn =newColumn;
  }

  // ============= Add Detail Column ============= //
  public void setDetailColumn(DataobjectColumn newColumn) {
    detailColumn = newColumn;
  }
}
