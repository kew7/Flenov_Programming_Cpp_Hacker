package com.cydsoft.databasemodeler;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DataobjectColumnType {
  private String name;
  private boolean isHaveLength;
  private boolean isHaveScale;

  public DataobjectColumnType(String name, boolean haveLength, boolean haveScale){
    setName(name);
    setHaveLength(haveLength);
    setIsHaveScale(haveScale);
  }

  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public boolean isHaveLength() {
    return isHaveLength;
  }
  public void setHaveLength(boolean haveLength) {
    this.isHaveLength = haveLength;
  }
  public boolean isIsHaveScale() {
    return isHaveScale;
  }
  public void setIsHaveScale(boolean isHaveScale) {
    this.isHaveScale = isHaveScale;
  }
}
