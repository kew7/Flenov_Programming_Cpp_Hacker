package com.cydsoft.common_files;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class MetadataTreeNode {
  // Constants
  public static final int DATABASE_EXPAND = -1;
  public static final int DATABASE_ROOT = 0;
  public static final int DATABASE_CATALOG = 1;
  public static final int DATABASE_SCHEME = 2;
  public static final int DATABASE_TABLE = 3;
  public static final int DATABASE_COLUMNROOT = 4;
  public static final int DATABASE_INDEXESROOT = 5;
  public static final int DATABASE_COLUMN = 6;
  public static final int DATABASE_INDEX = 7;

  // Properties
  String nodeObjectName;
  String catalogName;
  String SchemeName;
  String tableName;
  int nodeType;

  public MetadataTreeNode(String nodeObjectName, int nodeType) {
    this.nodeObjectName = nodeObjectName;
    this.nodeType = nodeType;
  }

  public MetadataTreeNode(String nodeObjectName, int nodeType, String catalogName) {
    this.nodeObjectName = nodeObjectName;
    this.nodeType = nodeType;
    this.catalogName = catalogName;
  }

  public MetadataTreeNode(String nodeObjectName, int nodeType, String catalogName, String SchemeName) {
    this.nodeObjectName = nodeObjectName;
    this.nodeType = nodeType;
    this.catalogName = catalogName;
    this.SchemeName = SchemeName;
  }

  public MetadataTreeNode(String nodeObjectName, int nodeType, String catalogName, String SchemeName, String tableName) {
    this.nodeObjectName = nodeObjectName;
    this.nodeType = nodeType;
    this.catalogName = catalogName;
    this.SchemeName = SchemeName;
    this.tableName = tableName;
  }

  public int getNodeType(){
    return nodeType;
  }

  public String getObjectName(){
    return nodeObjectName;
  }

  public String getSchemeName(){
    return SchemeName;
  }

  public String getTableName(){
    return tableName;
  }

  public String getCatalogName(){
    return catalogName;
  }

  public String toString() {
    return nodeObjectName;
  }
}
