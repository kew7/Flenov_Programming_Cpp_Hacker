package com.cydsoft.common_files;

import javax.swing.table.*;
import java.util.*;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import com.cydsoft.databasemodeler.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DatabaseTableViewAdapter extends AbstractTableModel {
  String[] columnNames = {};
  Vector rows = new Vector();
  ResultSetMetaData metaData;
  ResultSet resultSet;
  DBInterface database;
  Component parent;

  // ============= Constructor ============= //
  public DatabaseTableViewAdapter(Component parent) {
    this.parent = parent;
  }

  // ============= Get Row Count ============= //
  public int getRowCount() {
    return rows.size();
  }

  // ============= Get Column Count ============= //
  public int getColumnCount() {
    return columnNames.length;
  }

  // ============= Get Value At ============= //
  public Object getValueAt(int rowIndex, int columnIndex) {
    Vector row = (Vector)rows.get(rowIndex);
    return row.get(columnIndex);
  }

  // ============= Get Data From Statement ============= //
  public void getStatementData(ResultSet resultSet, DBInterface dbInterface) {
    try{
      // get metadata
      this.database = dbInterface;
      this.resultSet = resultSet;
      metaData = resultSet.getMetaData();

      // get column names
      int numberOfColumns =  metaData.getColumnCount();
      columnNames = new String[numberOfColumns];
      for(int column = 0; column < numberOfColumns; column++) {
        columnNames[column] = metaData.getColumnLabel(column+1);
      }

      // get rows
      rows = new Vector();
      while (resultSet.next()) {
        Vector newRow = new Vector();
        for (int i = 1; i <= getColumnCount(); i++) {
          newRow.addElement(resultSet.getObject(i));
        }
        rows.addElement(newRow);
      }

      // fire table changed
      fireTableChanged(null);
    }
    catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, ex.toString(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Get Data From Statement ============= //
  public String getColumnName(int column) {
    if (columnNames[column] == null) {
      return "";
    }
    else{
      return columnNames[column];
    }
  }

  // ============= get Column Class ============= //
  public Class getColumnClass(int column) {
    int type;
    try {
      type = metaData.getColumnType(column+1);
    }
    catch (SQLException e) {
      return super.getColumnClass(column);
    }

    switch(type) {
      case Types.CHAR:
      case Types.VARCHAR:
      case Types.LONGVARCHAR:
        return String.class;

      case Types.BIT:
        return Boolean.class;

      case Types.TINYINT:
      case Types.SMALLINT:
      case Types.INTEGER:
        return Integer.class;

      case Types.BIGINT:
        return Long.class;

      case Types.FLOAT:
      case Types.DOUBLE:
        return Double.class;

      case Types.DATE:
        return java.sql.Date.class;

      default:
        return Object.class;
    }
  }

  // ============= is Cell Editable ============= //
  public boolean isCellEditable(int row, int column) {	//(3)
    try {
      return metaData.isWritable(column+1);
    }
    catch (SQLException e) {
      return false;
    }
  }

  // ============= Value Representation ============= //
  public String valueRepresentation(int column, Object value) {
      int type;

      if (value == null)
        return "null";

      try {
          type = metaData.getColumnType(column+1);
      }
      catch (SQLException e) {
          return value.toString();
      }

      switch(type) {
      case Types.INTEGER:
      case Types.DOUBLE:
      case Types.FLOAT:
          return value.toString();
      case Types.BIT:
          return ((Boolean)value).booleanValue() ? "1" : "0";
      case Types.DATE:
          return value.toString();
      default:
          return "\""+value.toString()+"\"";
      }
  }

  // ============= Value Representation ============= //
  public void valueUpdate(int column, Object value) {
    int type;

    try {
      if (value == null)
         resultSet.updateNull(column);

          type = metaData.getColumnType(column+1);

      switch(type) {
        case Types.DOUBLE:
          resultSet.updateDouble(getColumnName(column), Double.valueOf(value.toString()).doubleValue());
          break;
        case Types.FLOAT:
          resultSet.updateFloat(getColumnName(column), Float.valueOf(value.toString()).floatValue());
          break;
        case Types.INTEGER:
        case Types.BIT:
        case Types.NUMERIC:
          resultSet.updateInt(getColumnName(column), Integer.valueOf(value.toString()).intValue());
          break;
        case Types.DATE:
          resultSet.updateDate(getColumnName(column), java.sql.Date.valueOf(value.toString()));
          break;
        default:
          resultSet.updateString(getColumnName(column), value.toString());
      }
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(parent, "Incorrect value", "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  // ============= Set value ============= //
  public void setValueAt(Object value, int row, int column) {
    if (JOptionPane.showConfirmDialog(parent, "Save changes?", "Attention", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)!=JOptionPane.OK_OPTION)
        return;
    try {
      if (database.isDirectUpdate()){
        // update with updatable result sets
        resultSet.absolute(row+1);
        valueUpdate(column, value.toString());
        resultSet.updateRow();
      }
      else {
        // update with query
        String catalogName = metaData.getCatalogName(column+1);
        String schemaName = metaData.getSchemaName(column+1);
        String tableName = metaData.getTableName(column+1);

        if (schemaName.compareTo("")!=0)
          tableName = schemaName+"."+tableName;
        if (catalogName.compareTo("")!=0)
          tableName = catalogName+"."+tableName;

        if (tableName == null) {
          JOptionPane.showMessageDialog(parent, "Table name returned null", "Error", JOptionPane.ERROR_MESSAGE);
        }

        String columnName = getColumnName(column);
        String query = "update "+tableName+
                " set "+columnName+
                " = "+valueRepresentation(column, value)+
                " where ";
        for(int col = 0; col < getColumnCount(); col++) {
          String colName = getColumnName(col);
          if (colName.equals("")) {
            continue;
          }
          if (col != 0) {
            query = query + " and ";
          }

          query = query + colName +" = "+
          valueRepresentation(col, getValueAt(row, col));
        }

        System.out.print(query);
        int res = database.executeUpdateOneRow(query);
        if (res==0){
          JOptionPane.showMessageDialog(parent, "Update error. Row not found", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }
        if (res>1){
          JOptionPane.showMessageDialog(parent, "Update error. More then 1 row founded", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(parent, "Update error", "Error", JOptionPane.ERROR_MESSAGE);
    }
    Vector dataRow = (Vector)rows.elementAt(row);
    dataRow.setElementAt(value, column);
  }

  // ============= Set value ============= //
  public void deleteRow(int row) {
    try {
      resultSet.absolute(row+1);
      resultSet.deleteRow();
      rows.remove(row);
      fireTableChanged(null);
    }
    catch (SQLException e) {
      JOptionPane.showMessageDialog(parent, "Update error", "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
}
