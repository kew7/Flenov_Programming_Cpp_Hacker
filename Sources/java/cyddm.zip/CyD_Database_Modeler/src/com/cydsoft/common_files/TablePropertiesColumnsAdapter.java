package com.cydsoft.common_files;

import javax.swing.table.*;
import java.util.Vector;
import com.cydsoft.databasemodeler.DataobjectColumn;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class TablePropertiesColumnsAdapter extends AbstractTableModel {
  Vector rows = new Vector();
  private String[] columnNames =
  {"Name", "Type", "Length", "Scale", "Description"};

  // ============= Constructor ============= //
  public TablePropertiesColumnsAdapter() {
  }

  // ============= Get Column Name ============= //
  public String getColumnName(int col) {
    return columnNames[col].toString();
  }

  // ============= Get Row Count ============= //
  public int getRowCount() {
    return rows.size();
  }

  // ============= Get Column Count ============= //
  public int getColumnCount() {
    return columnNames.length;
  }

  // ============= Get Value At ============= //
  public Object getValueAt(int rowIndex, int columnIndex) {
    Vector row = (Vector)rows.get(rowIndex);
    return row.get(columnIndex);
  }

  // ============= Add Row ============= //
  public void addRow(String name, String type, String length, String scale, String desc){
    Vector newRow = new Vector();

    newRow.add(name);
    newRow.add(type);
    newRow.add(length);
    newRow.add(scale);
    newRow.add(desc);

    rows.add(newRow);
    fireTableChanged(null);
  }

  // ============= Add Row ============= //
  public void addRow(DataobjectColumn tableColumn){
    Vector newRow = new Vector();

    newRow.add(tableColumn.getName());
    newRow.add(tableColumn.getType());
    newRow.add(tableColumn.getLengthString());
    newRow.add(tableColumn.getScaleString());
    newRow.add(tableColumn.getDescription());

    rows.add(newRow);
    fireTableChanged(null);
  }

  // ============= Update row ============= //
  public void updateRow(DataobjectColumn tableColumn, int index){
    Vector row = (Vector)rows.get(index);
    row.set(0, tableColumn.getName());
    row.set(1, tableColumn.getType());
    row.set(2, tableColumn.getLengthString());
    row.set(3, tableColumn.getScaleString());
    row.set(4, tableColumn.getDescription());
    fireTableChanged(null);
  }

  // ============= Delete row ============= //
  public void deleteRow(int rowIndex){
    rows.remove(rowIndex);
    fireTableChanged(null);
  }

  // ============= Delete rows ============= //
  public void deleteRows(){
    rows.clear();
    fireTableChanged(null);
  }
}
