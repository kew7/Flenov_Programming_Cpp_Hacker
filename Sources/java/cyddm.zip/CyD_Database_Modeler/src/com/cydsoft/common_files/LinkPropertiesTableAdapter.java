package com.cydsoft.common_files;

import javax.swing.table.*;
import java.util.*;
import com.cydsoft.databasemodeler.*;


/**
 * <p>Title: CyD Database Modeller</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class LinkPropertiesTableAdapter extends AbstractTableModel {
  Vector rows = new Vector();
  private String[] columnNames =
  {"Master table", "Master column", "Detail table", "Detail column"};
  ArrayList arrayTables;
  ArrayList arrayLinks;
  DataobjectTable selectedTable;

  // ============= Constructor ============= //
  public LinkPropertiesTableAdapter() {
  }

  // ============= Get Row Count ============= //
  public int getRowCount() {
    return rows.size();
  }

  // ============= Get Column Count ============= //
  public int getColumnCount() {
    return columnNames.length;
  }

  // ============= Get Value At ============= //
  public Object getValueAt(int rowIndex, int columnIndex) {
    Vector row = (Vector)rows.get(rowIndex);
    return row.get(columnIndex);
  }

  // ============= Set Table Properties ============= //
  public void setTableProperties(ArrayList arrayTables, ArrayList arrayLinks, DataobjectTable selectedTable){
    // save properties
    this.arrayTables = arrayTables;
    this.selectedTable = selectedTable;
    this.arrayLinks = arrayLinks;

    // search links for selected table
    for (int i=0; i < arrayLinks.size(); i++){
      DataobjectLink currentLink = (DataobjectLink)arrayLinks.get(i);
      if (currentLink.getMasterTable().equals(selectedTable) ||
         (currentLink.getDetailTable().equals(selectedTable))){
        Vector newRow = new Vector();
        newRow.add(currentLink.getMasterTable().getTableName());
        newRow.add(currentLink.getMasterColumn().getName());
        newRow.add(currentLink.getDetailTable().getTableName());
        newRow.add(currentLink.getDetailColumn().getName());
        newRow.add(currentLink);
        rows.add(newRow);
      }
    }
    fireTableChanged(null);
  }

  // ============= Get Column Name ============= //
  public String getColumnName(int col) {
    return columnNames[col].toString();
  }

  // ============= Delete row ============= //
  public void deleteLink(int rowIndex){
    Vector row = (Vector)rows.get(rowIndex);
    DataobjectLink link = (DataobjectLink)row.get(4);
    arrayLinks.remove(link);
    link = null;
    rows.remove(rowIndex);
    fireTableChanged(null);
  }
}
