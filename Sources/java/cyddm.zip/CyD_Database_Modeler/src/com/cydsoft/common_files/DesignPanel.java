package com.cydsoft.common_files;

import java.awt.dnd.*;
import java.awt.datatransfer.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import com.cydsoft.databasemodeler.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

public class DesignPanel extends JPanel {
  private ArrayList arrayTables;
  private ArrayList arrayLinks;
  private Point startDragPoint;
  DataobjectTable selectedTable = null;

  Dimension dimPanelSize;
  Image buffer = null;
  ModelerMainFrame mainFrame;

  // ============= Constructor ============= //
  public DesignPanel(ArrayList arrayTables, ArrayList arrayLinks) {
    try {
      this.arrayTables = arrayTables;
      this.arrayLinks = arrayLinks;
      this.mainFrame = mainFrame;

      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // ============= Paint ============= //
  public void paint(Graphics g)
  {
    if ((buffer == null) |  (dimPanelSize != this.getSize())){
      dimPanelSize = this.getSize();
      buffer = createImage(dimPanelSize.width, dimPanelSize.height);
    }
    // init graphics
    Graphics screengc = g;
    g = buffer.getGraphics();

    // fill background
    g.setColor(Color.white);
    g.fillRect(0, 0, dimPanelSize.width, dimPanelSize.height);

    g.setColor(Color.black);
    

    // draw links
    for (int linkIndex=0; linkIndex<arrayLinks.size(); linkIndex++){
      DataobjectLink link = (DataobjectLink)arrayLinks.get(linkIndex);
      Dimension masterTableSize = link.getMasterTable().getSize();
      Dimension detailTableSize = link.getDetailTable().getSize();
      Point masterTableLocation = link.getMasterTable().getLocation();
      Point detailTableLocation = link.getDetailTable().getLocation();

      g.drawLine(masterTableLocation.x+masterTableSize.width/2,
                 masterTableLocation.y+masterTableSize.height/2,
                 detailTableLocation.x+detailTableSize.width/2,
                 detailTableLocation.y+detailTableSize.height/2);
    }

    // draw tables
    for (int tableIndex=0; tableIndex<arrayTables.size(); tableIndex++){
      DataobjectTable table = (DataobjectTable)arrayTables.get(tableIndex);
      table.paint(g);
    }

    screengc.drawImage(buffer,0,0,null);
  }

  // ============= Mouse pressed ============= //
  void eMousePressed(MouseEvent e) {
    if (e.getButton()==e.BUTTON1)
    {
      startDragPoint = e.getPoint();
    }
  }

  // ============= Mouse released ============= //
  void eMouseReleased(MouseEvent e) {
    if (startDragPoint!=null){
      startDragPoint = null;
      repaint();
    }
  }

  // ============= Mouse Dragging ============= //
  void eMouseDragged(MouseEvent e) {
    if ((selectedTable == null) | (startDragPoint == null))
      return;
    // get current position
    Point tablePosition = selectedTable.getLocation();
    Dimension tableSize = selectedTable.getSize();

    // clear last rectangle
    Graphics g = getGraphics();
    g.setColor(Color.black);
    g.setXORMode(Color.white);
    g.drawRect(tablePosition.x, tablePosition.y, tableSize.width, tableSize.height);

    // calculate new position
    int x = tablePosition.x + e.getX() - startDragPoint.x;
    int y = tablePosition.y + e.getY() - startDragPoint.y;
    selectedTable.setLocation(x, y);
    startDragPoint = e.getPoint();

    // draw new rectangle
    g.setColor(Color.white);
    g.setXORMode(Color.black);
    g.drawRect(x, y, tableSize.width, tableSize.height);
    mainFrame.setProjectChanged();
  }

  // ============= jbInit ============= //
  private void jbInit() throws Exception {
    // mouse event
    addMouseListener(new java.awt.event.MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        eMousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        eMouseReleased(e);
      }
    });

    // mouse move event
    addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        eMouseDragged(e);
      }
    });
  }

  // ============= Set Selected Panel ============= //
  public void setSelectedPanel(DataobjectTable selectedTable){
    this.selectedTable = selectedTable;
  }

  public void setMainFrame(ModelerMainFrame mainFrame){
    this.mainFrame = mainFrame;
  }
}
