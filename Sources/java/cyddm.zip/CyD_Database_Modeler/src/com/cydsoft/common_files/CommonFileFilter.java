package com.cydsoft.common_files;

import java.io.File;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.*;

/**
 * <p>Title: Common File Filter </p>
 * <p>Description: CyD Database Modeler Main Frame</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: CyD Software Labs</p>
 * @author Michael Flenov 
 * @web: http://www.flenov.net 
 * @web: http://www.cydsoft.com
 * @version 1.0
 */

 
public class CommonFileFilter extends FileFilter {
    private HashMap filters = null;
    private String description = null;

    // ============== Constructor ============== //
    public CommonFileFilter() {
      this.filters = new HashMap();
    }

    // ============== Constructor ============== //
    public CommonFileFilter(String extension) {
      this(extension,null);
    }

    // ============== Constructor ============== //
    public CommonFileFilter(String extension, String description) {
      this();
      addExtension(extension);
      setDescription(description);
    }

    // ============== Accept File ============== //
    public boolean accept(File f){
	if (f == null)
          return false;

        if (f.isDirectory())
          return true;

        String extension = getExtension(f);
        if (extension != null && filters.get(getExtension(f)) != null)
          return true;
        else
          return false;
    }

    // ============== Get Extension ============== //
    public String getExtension(File f) {
      String filename = f.getName();
      int dotIndex = filename.lastIndexOf('.');
      if (dotIndex>0 & dotIndex<filename.length()-1)
        return filename.substring(dotIndex + 1).toLowerCase();
      else
        return null;
    }

    // ============== Add Extension ============== //
    public void addExtension(String extension) {
	filters.put(extension.toLowerCase(), extension.toLowerCase());
    }

    // ============== Get Description ============== //
    public String getDescription() {
	return description;
    }

    // ============== Set Description ============== //
    public void setDescription(String description) {
	this.description = description;
    }
}
